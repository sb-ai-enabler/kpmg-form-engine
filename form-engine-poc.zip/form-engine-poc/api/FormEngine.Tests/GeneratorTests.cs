using FormEngine.Templates;

namespace FormEngine.Tests;

public class GeneratorTests
{
    private static TemplateFile Version(int version, string properties, string required = "", VersionStatus status = VersionStatus.Published) =>
        new("leave-request", version, status, $$"""
            {
              "status": "published",
              "schema": {
                "type": "object",
                "properties": { {{properties}} },
                "required": [ {{required}} ]
              },
              "uischema": { "type": "VerticalLayout", "elements": [] }
            }
            """);

    private static FormField Field(FormModel model, string jsonName) => model.Fields.Single(f => f.JsonName == jsonName);

    [Theory]
    [InlineData("""{ "type": "string" }""", "string")]
    [InlineData("""{ "type": "string", "format": "email" }""", "string")]
    [InlineData("""{ "type": "string", "format": "date" }""", "DateOnly")]
    [InlineData("""{ "type": "string", "format": "date-time" }""", "DateTimeOffset")]
    [InlineData("""{ "type": "number" }""", "decimal")]
    [InlineData("""{ "type": "integer" }""", "long")]
    [InlineData("""{ "type": "boolean" }""", "bool")]
    public void Maps_schema_types_to_clr_types(string property, string expected)
    {
        var model = FormModel.Build("leave-request", [Version(1, $$""" "value": {{property}} """)]);

        Assert.Equal(expected, Field(model, "value").ClrType);
    }

    [Theory]
    [InlineData("""{ "type": "object", "properties": {} }""")]
    [InlineData("""{ "type": "array", "items": { "type": "string" } }""")]
    [InlineData("""{ "type": ["string", "null"] }""")]
    public void Rejects_fields_that_cannot_be_columns(string property)
    {
        var ex = Assert.Throws<FormModelException>(() => FormModel.Build("leave-request", [Version(1, $$""" "value": {{property}} """)]));

        Assert.Contains("'value'", ex.Message);
    }

    [Fact]
    public void Column_is_required_only_when_required_in_every_version()
    {
        var model = FormModel.Build("leave-request",
        [
            Version(1, """ "always": { "type": "number" }, "sometimes": { "type": "number" } """, """ "always", "sometimes" """),
            Version(2, """ "always": { "type": "number" }, "sometimes": { "type": "number" } """, """ "always" """),
        ]);

        Assert.False(Field(model, "always").IsNullable);
        Assert.True(Field(model, "sometimes").IsNullable);
    }

    [Fact]
    public void Added_field_is_nullable_even_when_required_by_the_new_version()
    {
        var model = FormModel.Build("leave-request",
        [
            Version(1, """ "a": { "type": "string" } """, """ "a" """),
            Version(2, """ "a": { "type": "string" }, "b": { "type": "string" } """, """ "a", "b" """),
        ]);

        Assert.True(Field(model, "b").IsNullable);
    }

    [Fact]
    public void Removed_field_keeps_its_column_and_becomes_nullable()
    {
        var model = FormModel.Build("leave-request",
        [
            Version(1, """ "a": { "type": "string" }, "old": { "type": "string" } """, """ "a", "old" """),
            Version(2, """ "a": { "type": "string" } """, """ "a" """),
        ]);

        Assert.True(Field(model, "old").IsNullable);
    }

    [Fact]
    public void Changing_a_field_type_between_versions_fails()
    {
        var ex = Assert.Throws<FormModelException>(() => FormModel.Build("leave-request",
        [
            Version(1, """ "a": { "type": "string" } """),
            Version(2, """ "a": { "type": "number" } """),
        ]));

        Assert.Contains("can't change", ex.Message);
    }

    [Fact]
    public void Draft_versions_do_not_affect_the_table()
    {
        var published = Version(1, """ "a": { "type": "string" } """);
        var draft = Version(2, """ "a": { "type": "number" }, "b": { "type": "string" } """, status: VersionStatus.Draft);

        var model = FormModel.Build("leave-request", [published, draft]);

        Assert.Equal(FormModel.Build("leave-request", [published]).Fingerprint, model.Fingerprint);
    }

    [Fact]
    public void Form_with_only_drafts_cannot_be_generated() =>
        Assert.Throws<FormModelException>(() => FormModel.Build("leave-request", [Version(1, "", status: VersionStatus.Draft)]));

    [Theory]
    [InlineData(""" "id": { "type": "number" } """)]
    [InlineData(""" "createdAt": { "type": "string" } """)]
    [InlineData(""" "cost-centre": { "type": "string" }, "costCentre": { "type": "string" } """)]
    [InlineData(""" "1st": { "type": "string" } """)]
    public void Rejects_field_names_that_would_clash_or_be_invalid(string properties) =>
        Assert.Throws<FormModelException>(() => FormModel.Build("leave-request", [Version(1, properties)]));

    [Theory]
    [InlineData("Leave-Request")]
    [InlineData("leave request")]
    public void Rejects_invalid_form_keys(string key) =>
        Assert.Throws<FormModelException>(() => FormModel.Build(key, [Version(1, """ "a": { "type": "string" } """)]));

    [Fact]
    public void Fingerprint_changes_when_columns_change()
    {
        var before = FormModel.Build("leave-request", [Version(1, """ "a": { "type": "string" } """)]);
        var after = FormModel.Build("leave-request", [Version(1, """ "a": { "type": "string", "maxLength": 5 } """)]);

        Assert.NotEqual(before.Fingerprint, after.Fingerprint);
    }

    [Fact]
    public void Generates_every_layer_for_a_form()
    {
        var model = FormModel.Build("leave-request", [Version(1, """ "days": { "type": "number" } """, """ "days" """)]);

        var files = CodeGenerator.Generate(model);

        Assert.Equal(
            [
                "GetLeaveRequestHandler.g.cs", "GetLeaveRequestQuery.g.cs", "ILeaveRequestRepository.g.cs",
                "LeaveRequestController.g.cs", "LeaveRequestDto.g.cs", "LeaveRequestRegistration.g.cs",
                "LeaveRequestRepository.g.cs", "LeaveRequestSubmission.g.cs",
                "SubmitLeaveRequestCommand.g.cs", "SubmitLeaveRequestHandler.g.cs",
            ],
            files.Keys.Select(path => path.Split('/')[1]).Order(StringComparer.Ordinal));

        var entity = files["LeaveRequest/LeaveRequestSubmission.g.cs"];
        Assert.Contains("[Table(\"LeaveRequestSubmissions\")]", entity);
        Assert.Contains("public decimal Days { get; set; }", entity);
        Assert.Contains("[JsonPropertyName(\"days\")] public decimal? Days", files["LeaveRequest/LeaveRequestDto.g.cs"]);
        Assert.Contains("[Route(\"api/forms/leave-request\")]", files["LeaveRequest/LeaveRequestController.g.cs"]);
    }

    [Fact]
    public void Checked_in_code_matches_the_templates()
    {
        var directory = new DirectoryInfo(AppContext.BaseDirectory);
        while (!File.Exists(Path.Combine(directory!.FullName, "FormEngine.slnx")))
            directory = directory.Parent;

        var features = Path.Combine(directory.FullName, CodeGenerator.ApiFeaturesPath);
        var expected = CodeGenerator.GenerateAll(Path.Combine(directory.FullName, CodeGenerator.ApiTemplatesPath));

        foreach (var (path, content) in expected)
        {
            var actual = File.ReadAllText(Path.Combine(features, path));
            Assert.True(actual.ReplaceLineEndings("\n") == content.ReplaceLineEndings("\n"), $"{path} is out of date.");
        }
    }
}
