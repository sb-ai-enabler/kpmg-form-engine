using System.Reflection;
using FormEngine.Api.Behaviours;
using FormEngine.Api.Lookups;
using FormEngine.Api.Templates;
using FormEngine.Templates;

namespace FormEngine.Tests;

public class TemplateValidationTests
{
    private static readonly Assembly ApiAssembly = typeof(TemplateStore).Assembly;

    private static PublishValidator Validator() => new(
        new BehaviourRegistry([new FieldLimitBehaviour(), new TestBehaviour("records", _ => BehaviourResult.Empty)]),
        new LookupRegistry([new DepartmentsLookup()]));

    private static string Definition(string behaviours, string? uiElements = null) => $$"""
        {
          "status": "published",
          "schema": { "type": "object", "properties": { "days": { "type": "number" }, "note": { "type": "string" } } },
          "uischema": {
            "type": "VerticalLayout",
            "elements": [ {{uiElements ?? """{ "type": "Control", "scope": "#/properties/days" }"""}} ]
          },
          "behaviours": [ {{behaviours}} ]
        }
        """;

    [Theory]
    [InlineData("""{ "trigger": "beforeSave", "behaviour": "does-not-exist" }""", null)]
    [InlineData("""{ "trigger": "beforeSave", "behaviour": "field-limit", "args": { "field": "days" } }""", null)]
    [InlineData("""{ "trigger": "duringSave", "behaviour": "records" }""", null)]
    [InlineData("""{ "trigger": "beforeSave", "behaviour": "records", "when": { "scope": "#/properties/days", "schema": { "const": 1 } } }""", null)]
    [InlineData("", """{ "type": "Control", "scope": "#/properties/typo" }""")]
    [InlineData("", """{ "type": "Control", "scope": "#/properties/days", "options": { "lookup": "does-not-exist" } }""")]
    [InlineData("", """{ "type": "Control", "scope": "#/properties/days", "rule": { "effect": "SHOW", "condition": { "type": "AND", "conditions": [] } } }""")]
    [InlineData("", """{ "type": "Control", "scope": "#/properties/days", "rule": { "effect": "BLINK", "condition": { "scope": "#/properties/note", "schema": {}, "failWhenUndefined": true } } }""")]
    public void Publish_checks_reject_invalid_templates(string behaviours, string? uiElements) =>
        Assert.NotEmpty(Validator().Validate(Definition(behaviours, uiElements)));

    [Fact]
    public void Publish_checks_reject_a_hideable_field_in_root_required()
    {
        const string definition = """
            {
              "schema": { "type": "object", "properties": { "a": { "type": "string" }, "b": { "type": "string" } }, "required": ["b"] },
              "uischema": { "type": "VerticalLayout", "elements": [
                { "type": "Control", "scope": "#/properties/b",
                  "rule": { "effect": "SHOW", "condition": { "scope": "#/properties/a", "schema": { "const": "x" }, "failWhenUndefined": true } } }
              ] }
            }
            """;

        Assert.NotEmpty(Validator().Validate(definition));
    }

    [Fact]
    public void Startup_fails_when_a_published_template_has_no_generated_code()
    {
        var store = new TemplateStore([new TemplateFile("no-code-yet", 1, VersionStatus.Published, Definition(""))]);

        var problem = Assert.Single(store.FindProblems(Validator(), ApiAssembly));

        Assert.Contains("no generated code", problem);
        Assert.Contains("generate-form.ps1 no-code-yet", problem);
    }

    [Fact]
    public void Startup_ignores_a_form_with_only_drafts()
    {
        var store = new TemplateStore([new TemplateFile("work-in-progress", 1, VersionStatus.Draft, Definition(""))]);

        Assert.Empty(store.FindProblems(Validator(), ApiAssembly));
    }

    [Fact]
    public void Startup_fails_when_generated_code_is_out_of_date()
    {
        var store = new TemplateStore(
        [
            new TemplateFile("expense-claim", 1, VersionStatus.Published, Definition("")),
        ]);

        var problem = Assert.Single(store.FindProblems(Validator(), ApiAssembly));

        Assert.Contains("doesn't match", problem);
    }

    [Fact]
    public void Startup_fails_when_a_published_template_is_invalid()
    {
        var store = new TemplateStore(
        [
            new TemplateFile("broken", 1, VersionStatus.Published, Definition("""{ "trigger": "beforeSave", "behaviour": "does-not-exist" }""")),
        ]);

        Assert.Contains(store.FindProblems(Validator(), ApiAssembly), problem => problem.Contains("does-not-exist"));
    }
}
