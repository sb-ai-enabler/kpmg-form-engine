using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
using FormEngine.Api.Data;
using FormEngine.Api.Features.ExpenseClaim;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace FormEngine.Tests;

public class ApiFactory : WebApplicationFactory<Program>
{
    private readonly string _dbPath = Path.Combine(Path.GetTempPath(), $"formengine-test-{Guid.NewGuid():N}.db");

    protected override void ConfigureWebHost(IWebHostBuilder builder) =>
        builder.UseSetting("ConnectionStrings:Default", $"Data Source={_dbPath};Pooling=False");

    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);
        File.Delete(_dbPath);
    }
}

/// <summary>End-to-end tests of the expense-claim form through its generated controller, handlers and repository.</summary>
public class ApiTests(ApiFactory factory) : IClassFixture<ApiFactory>
{
    private readonly HttpClient _client = factory.CreateClient();

    private static JsonObject ValidClaim(string department = "engineering", string costCentre = "EN-100", double amount = 100) => new()
    {
        ["employeeName"] = "Sam Taylor",
        ["email"] = "sam@example.com",
        ["department"] = department,
        ["costCentre"] = costCentre,
        ["amount"] = amount,
    };

    private Task<HttpResponseMessage> Submit(int version, JsonObject data) =>
        _client.PostAsJsonAsync($"/api/forms/expense-claim/versions/{version}/submissions", data);

    private static async Task<string[]> ErrorPaths(HttpResponseMessage response)
    {
        Assert.Equal(HttpStatusCode.UnprocessableEntity, response.StatusCode);
        var body = await response.Content.ReadFromJsonAsync<JsonObject>();
        return body!["errors"]!.AsArray().Select(e => e!["path"]!.GetValue<string>()).ToArray();
    }

    private async Task<ExpenseClaimSubmission> StoredRow(HttpResponseMessage response)
    {
        var id = (await response.Content.ReadFromJsonAsync<JsonObject>())!["id"]!.GetValue<int>();
        using var scope = factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        return await db.Set<ExpenseClaimSubmission>().SingleAsync(row => row.Id == id);
    }

    [Fact]
    public async Task Form_endpoint_returns_latest_published_version_without_behaviours()
    {
        var form = await _client.GetFromJsonAsync<JsonObject>("/api/forms/expense-claim");

        Assert.Equal(2, form!["version"]!.GetValue<int>());
        Assert.NotNull(form["schema"]);
        Assert.NotNull(form["uischema"]);
        Assert.Null(form["behaviours"]);
    }

    [Fact]
    public async Task Versions_endpoint_lists_the_files_on_disk()
    {
        var versions = await _client.GetFromJsonAsync<JsonArray>("/api/forms/expense-claim/versions");

        Assert.Equal([1, 2], versions!.Select(v => v!["version"]!.GetValue<int>()));
        Assert.All(versions, v => Assert.Equal("Published", v!["status"]!.GetValue<string>()));
    }

    [Fact]
    public async Task Valid_submission_is_stored_in_typed_columns()
    {
        var claim = ValidClaim(amount: 123.45);
        claim["expenseDate"] = "2026-03-14";
        claim["hasReceipt"] = true;
        claim["receiptReference"] = "RCPT-12";

        var response = await Submit(1, claim);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var row = await StoredRow(response);
        Assert.Equal(1, row.TemplateVersion);
        Assert.Equal("Sam Taylor", row.EmployeeName);
        Assert.Equal(123.45m, row.Amount);
        Assert.Equal(new DateOnly(2026, 3, 14), row.ExpenseDate);
        Assert.True(row.HasReceipt);
        Assert.Equal("RCPT-12", row.ReceiptReference);
        Assert.Contains("EXP-", row.Outputs);
    }

    [Fact]
    public async Task Response_and_get_endpoint_return_the_submission()
    {
        var response = await Submit(1, ValidClaim());

        var body = await response.Content.ReadFromJsonAsync<JsonObject>();
        Assert.Equal(1, body!["version"]!.GetValue<int>());
        Assert.Equal("expense-claim", body["templateKey"]!.GetValue<string>());
        Assert.StartsWith("EXP-", body["outputs"]!["reference"]!.GetValue<string>());

        var stored = await _client.GetFromJsonAsync<JsonObject>(response.Headers.Location);
        Assert.Equal("Sam Taylor", stored!["data"]!["employeeName"]!.GetValue<string>());
        Assert.Equal(body["outputs"]!["reference"]!.GetValue<string>(), stored["outputs"]!["reference"]!.GetValue<string>());
    }

    [Fact]
    public async Task Get_returns_404_for_an_unknown_submission() =>
        Assert.Equal(HttpStatusCode.NotFound, (await _client.GetAsync("/api/forms/expense-claim/submissions/999999")).StatusCode);

    [Fact]
    public async Task Missing_and_invalid_fields_are_reported_by_field()
    {
        var claim = ValidClaim();
        claim.Remove("employeeName");
        claim["email"] = "not-an-email";

        var paths = await ErrorPaths(await Submit(1, claim));

        Assert.Contains("/employeeName", paths);
        Assert.Contains("/email", paths);
        Assert.DoesNotContain("", paths);
    }

    [Fact]
    public async Task Receipt_reference_is_required_when_shown()
    {
        var claim = ValidClaim();
        claim["hasReceipt"] = true;

        Assert.Equal(["/receiptReference"], await ErrorPaths(await Submit(1, claim)));
    }

    [Fact]
    public async Task Value_for_a_hidden_field_is_stored_as_null()
    {
        var claim = ValidClaim();
        claim["hasReceipt"] = false;
        claim["receiptReference"] = "invalid but hidden";

        var response = await Submit(1, claim);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        Assert.Null((await StoredRow(response)).ReceiptReference);
    }

    [Fact]
    public async Task Hidden_field_is_left_out_of_the_response()
    {
        var response = await Submit(1, ValidClaim());

        var body = await response.Content.ReadFromJsonAsync<JsonObject>();
        Assert.False(body!["data"]!.AsObject().ContainsKey("receiptReference"));
    }

    [Fact]
    public async Task Unknown_field_is_rejected()
    {
        var claim = ValidClaim();
        claim["isAdmin"] = true;

        Assert.Equal(HttpStatusCode.UnprocessableEntity, (await Submit(1, claim)).StatusCode);
    }

    [Fact]
    public async Task Value_of_the_wrong_type_is_reported_on_its_field()
    {
        var claim = ValidClaim();
        claim["amount"] = "lots";

        Assert.Equal(["/amount"], await ErrorPaths(await Submit(1, claim)));
    }

    [Fact]
    public async Task Missing_required_number_is_reported_rather_than_saved_as_zero()
    {
        var claim = ValidClaim();
        claim.Remove("amount");

        Assert.Equal(["/amount"], await ErrorPaths(await Submit(1, claim)));
    }

    [Fact]
    public async Task Cost_centre_from_another_department_is_rejected() =>
        Assert.Equal(["/costCentre"], await ErrorPaths(await Submit(1, ValidClaim("engineering", "TR-100"))));

    [Fact]
    public async Task Field_limit_only_applies_when_its_condition_matches()
    {
        Assert.Equal(["/amount"], await ErrorPaths(await Submit(1, ValidClaim("travel", "TR-100", 6000))));
        Assert.Equal(HttpStatusCode.Created, (await Submit(1, ValidClaim("engineering", "EN-100", 6000))).StatusCode);
    }

    [Fact]
    public async Task Versions_apply_their_own_args()
    {
        var claim = ValidClaim("travel", "TR-100", 3000);

        var onV1 = await Submit(1, claim);
        Assert.Equal(HttpStatusCode.Created, onV1.StatusCode);
        Assert.Equal(1, (await StoredRow(onV1)).TemplateVersion);

        Assert.Equal(["/amount"], await ErrorPaths(await Submit(2, claim)));
    }

    [Fact]
    public async Task Unknown_version_returns_404() =>
        Assert.Equal(HttpStatusCode.NotFound, (await Submit(99, ValidClaim())).StatusCode);

    [Fact]
    public async Task Lookup_endpoint_filters_by_parameter()
    {
        var options = await _client.GetFromJsonAsync<JsonArray>("/api/lookups/costCentres?department=marketing");

        Assert.Equal("MK-100", Assert.Single(options!)!["value"]!.GetValue<string>());
        Assert.Equal(HttpStatusCode.NotFound, (await _client.GetAsync("/api/lookups/nope")).StatusCode);
    }
}
