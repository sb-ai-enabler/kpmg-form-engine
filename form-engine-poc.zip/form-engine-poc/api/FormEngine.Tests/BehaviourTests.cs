using System.Text.Json.Nodes;
using FormEngine.Api.Behaviours;

namespace FormEngine.Tests;

public class BehaviourTests
{
    private static BehaviourContext Context(string data, string args, int? submissionId = null) =>
        new("any-template", 1, Triggers.BeforeSave, JsonNode.Parse(data)!.AsObject(), JsonNode.Parse(args)!.AsObject(), submissionId);

    [Theory]
    [InlineData(100, false)]
    [InlineData(100.5, true)]
    public async Task FieldLimit_rejects_only_values_over_the_max(double value, bool rejected)
    {
        var ctx = Context($$"""{ "days": {{value}} }""", """{ "field": "days", "max": 100 }""");

        var result = await new FieldLimitBehaviour().ExecuteAsync(ctx, default);

        Assert.Equal(rejected, result.FieldErrors.Count == 1);
    }

    [Fact]
    public async Task FieldLimit_reports_the_configured_field_and_message()
    {
        var ctx = Context("""{ "days": 30 }""", """{ "field": "days", "max": 10, "message": "Too long" }""");

        var result = await new FieldLimitBehaviour().ExecuteAsync(ctx, default);

        Assert.Equal(new FieldError("/days", "Too long"), Assert.Single(result.FieldErrors));
    }

    [Fact]
    public async Task FieldLimit_ignores_a_missing_field()
    {
        var result = await new FieldLimitBehaviour().ExecuteAsync(Context("{}", """{ "field": "days", "max": 10 }"""), default);

        Assert.Empty(result.FieldErrors);
    }

    [Fact]
    public async Task GenerateReference_uses_prefix_and_submission_id()
    {
        var result = await new GenerateReferenceBehaviour().ExecuteAsync(Context("{}", """{ "prefix": "LV" }""", 42), default);

        Assert.Matches(@"^LV-\d{4}-000042$", result.Outputs["reference"]!.GetValue<string>());
    }

    [Fact]
    public async Task GenerateReference_needs_a_saved_submission() =>
        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            new GenerateReferenceBehaviour().ExecuteAsync(Context("{}", """{ "prefix": "LV" }"""), default));
}
