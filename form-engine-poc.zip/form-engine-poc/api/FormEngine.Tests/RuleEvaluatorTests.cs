using System.Text.Json.Nodes;
using FormEngine.Api.Rules;

namespace FormEngine.Tests;

public class RuleEvaluatorTests
{
    private static JsonObject Obj(string json) => JsonNode.Parse(json)!.AsObject();

    private static readonly JsonObject Condition =
        Obj("""{ "scope": "#/properties/flag", "schema": { "const": true }, "failWhenUndefined": true }""");

    [Theory]
    [InlineData("""{ "flag": true }""", true)]
    [InlineData("""{ "flag": false }""", false)]
    [InlineData("""{ }""", false)]
    public void Evaluates_condition_with_failWhenUndefined(string data, bool expected) =>
        Assert.Equal(expected, RuleEvaluator.Evaluate(Condition, Obj(data)));

    [Fact]
    public void Undefined_value_passes_without_failWhenUndefined()
    {
        var condition = Obj("""{ "scope": "#/properties/flag", "schema": { "const": true } }""");
        Assert.True(RuleEvaluator.Evaluate(condition, Obj("{}")));
    }

    [Fact]
    public void Resolves_nested_scopes()
    {
        var condition = Obj("""{ "scope": "#/properties/a/properties/b", "schema": { "const": 1 }, "failWhenUndefined": true }""");
        Assert.True(RuleEvaluator.Evaluate(condition, Obj("""{ "a": { "b": 1 } }""")));
        Assert.False(RuleEvaluator.Evaluate(condition, Obj("""{ "a": { "b": 2 } }""")));
    }

    [Fact]
    public void Evaluates_repeatedly_without_schema_registry_conflicts()
    {
        for (var i = 0; i < 3; i++)
            Assert.True(RuleEvaluator.Evaluate(Condition, Obj("""{ "flag": true }""")));
    }

    [Theory]
    [InlineData("SHOW", true, true)]
    [InlineData("SHOW", false, false)]
    [InlineData("ENABLE", false, false)]
    [InlineData("HIDE", true, false)]
    [InlineData("DISABLE", true, false)]
    [InlineData("DISABLE", false, true)]
    public void Applies_rule_effects(string effect, bool flag, bool expected)
    {
        var rule = new JsonObject { ["effect"] = effect, ["condition"] = Condition.DeepClone() };
        var data = new JsonObject { ["flag"] = flag };
        Assert.Equal(expected, RuleEvaluator.IsActive([rule], data));
    }

    [Fact]
    public void Prune_removes_hidden_and_disabled_values_but_keeps_active_ones()
    {
        var uiSchema = Obj("""
            {
              "type": "VerticalLayout",
              "elements": [
                { "type": "Control", "scope": "#/properties/kept" },
                { "type": "Control", "scope": "#/properties/hidden",
                  "rule": { "effect": "SHOW", "condition": { "scope": "#/properties/flag", "schema": { "const": true }, "failWhenUndefined": true } } },
                { "type": "Control", "scope": "#/properties/disabled",
                  "rule": { "effect": "DISABLE", "condition": { "scope": "#/properties/flag", "schema": { "const": false }, "failWhenUndefined": true } } },
                { "type": "Group",
                  "rule": { "effect": "HIDE", "condition": { "scope": "#/properties/flag", "schema": { "const": false }, "failWhenUndefined": true } },
                  "elements": [ { "type": "Control", "scope": "#/properties/inGroup" } ] }
              ]
            }
            """);
        var data = Obj("""{ "flag": false, "kept": "a", "hidden": "b", "disabled": "c", "inGroup": "d" }""");

        var pruned = UiSchema.Prune(uiSchema, data);

        Assert.Equal("""{"flag":false,"kept":"a"}""", pruned.ToJsonString());
        Assert.True(data.ContainsKey("hidden"));
    }
}
