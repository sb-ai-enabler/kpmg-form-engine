using System.Text.Json.Nodes;
using FormEngine.Api.Behaviours;
using FormEngine.Api.Forms;
using FormEngine.Api.Lookups;
using FormEngine.Api.Templates;
using FormEngine.Templates;
using Microsoft.Extensions.Logging.Abstractions;

namespace FormEngine.Tests;

public class TestBehaviour(string key, Func<BehaviourContext, BehaviourResult> execute) : IBehaviour
{
    public string Key => key;
    public JsonNode ArgsSchema { get; } = JsonNode.Parse("""{ "type": "object" }""")!;
    public Task<BehaviourResult> ExecuteAsync(BehaviourContext ctx, CancellationToken ct) => Task.FromResult(execute(ctx));
}

public class SubmissionProcessorTests
{
    private readonly List<string> _calls = [];

    private static string Definition(string behaviours) => $$"""
        {
          "schema": { "type": "object", "properties": { "days": { "type": "number" } } },
          "uischema": { "type": "VerticalLayout", "elements": [ { "type": "Control", "scope": "#/properties/days" } ] },
          "behaviours": [ {{behaviours}} ]
        }
        """;

    private SubmissionProcessor Processor(string behaviours, VersionStatus status = VersionStatus.Published)
    {
        IBehaviour[] registered =
        [
            new FieldLimitBehaviour(),
            new TestBehaviour("throws", _ => throw new InvalidOperationException("boom")),
            new TestBehaviour("records", ctx =>
            {
                _calls.Add($"{ctx.Trigger}:{ctx.Args["name"]}");
                return BehaviourResult.Empty;
            }),
        ];
        return new SubmissionProcessor(
            new TemplateStore([new TemplateFile("leave-request", 1, status, Definition(behaviours))]),
            new BehaviourRegistry(registered),
            new LookupRegistry([]),
            NullLogger<SubmissionProcessor>.Instance);
    }

    private static JsonObject Days(int days) => JsonNode.Parse($$"""{ "days": {{days}} }""")!.AsObject();

    [Fact]
    public async Task Field_limit_can_be_reused_by_another_template()
    {
        var processor = Processor("""{ "trigger": "beforeSave", "behaviour": "field-limit", "args": { "field": "days", "max": 10 } }""");

        var over = await processor.PrepareAsync("leave-request", 1, Days(11), default);
        var within = await processor.PrepareAsync("leave-request", 1, Days(10), default);

        var rejected = Assert.IsType<SubmissionFailure.Rejected>(over.Failure);
        Assert.Equal("/days", Assert.Single(rejected.Errors).Path);
        Assert.Null(within.Failure);
    }

    [Theory]
    [InlineData(VersionStatus.Draft)]
    [InlineData(VersionStatus.Retired)]
    public async Task Only_published_versions_accept_submissions(VersionStatus status)
    {
        var result = await Processor("", status).PrepareAsync("leave-request", 1, Days(1), default);

        Assert.IsType<SubmissionFailure.NotPublished>(result.Failure);
    }

    [Fact]
    public async Task Unknown_version_is_not_found()
    {
        var result = await Processor("").PrepareAsync("leave-request", 2, Days(1), default);

        Assert.IsType<SubmissionFailure.VersionNotFound>(result.Failure);
    }

    [Fact]
    public async Task BeforeSave_exception_propagates_so_nothing_is_saved() =>
        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            Processor("""{ "trigger": "beforeSave", "behaviour": "throws" }""").PrepareAsync("leave-request", 1, Days(1), default));

    [Fact]
    public async Task AfterSave_exception_is_recorded_as_a_failed_run()
    {
        var processor = Processor("""{ "trigger": "afterSave", "behaviour": "throws" }""");
        var prepared = await processor.PrepareAsync("leave-request", 1, Days(1), default);

        var completed = await processor.CompleteAsync(prepared.Submission!, 7);

        var run = JsonNode.Parse(completed.BehaviourRuns)!.AsArray().Single()!;
        Assert.Equal("Failed", run["status"]!.GetValue<string>());
        Assert.Equal("boom", run["error"]!.GetValue<string>());
    }

    [Fact]
    public async Task Behaviours_run_in_template_order_around_the_save()
    {
        var processor = Processor("""
            { "trigger": "afterSave", "behaviour": "records", "args": { "name": "third" } },
            { "trigger": "beforeSave", "behaviour": "records", "args": { "name": "first" } },
            { "trigger": "beforeSave", "behaviour": "records", "args": { "name": "second" } }
            """);

        var prepared = await processor.PrepareAsync("leave-request", 1, Days(1), default);
        Assert.Equal(["beforeSave:first", "beforeSave:second"], _calls);

        await processor.CompleteAsync(prepared.Submission!, 7);
        Assert.Equal(["beforeSave:first", "beforeSave:second", "afterSave:third"], _calls);
    }
}
