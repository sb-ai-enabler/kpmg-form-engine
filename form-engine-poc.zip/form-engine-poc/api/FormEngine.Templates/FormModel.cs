using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;

namespace FormEngine.Templates;

public class FormModelException(string message) : Exception(message);

public record FormField(string JsonName, string PropertyName, string ClrType, bool IsNullable, int? MaxLength)
{
    public string TypeName => IsNullable ? ClrType + "?" : ClrType;
}

/// <summary>The combined fields of all of a form's published and retired versions.</summary>
public partial record FormModel(string Key, string Name, IReadOnlyList<FormField> Fields)
{
    private static readonly string[] ReservedProperties = ["Id", "TemplateVersion", "CreatedAt", "Outputs", "BehaviourRuns"];

    public string EntityName => Name + "Submission";

    /// <summary>Changes whenever the generated columns would change, so the API can detect stale code.</summary>
    public string Fingerprint
    {
        get
        {
            var text = string.Join('\n', Fields.Select(f => $"{f.JsonName}:{f.TypeName}:{f.MaxLength}"));
            return Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(text)))[..16];
        }
    }

    /// <exception cref="FormModelException">The template can't be turned into a table.</exception>
    public static FormModel Build(string key, IEnumerable<TemplateFile> files)
    {
        if (!FormKey().IsMatch(key))
            throw new FormModelException($"'{key}' isn't a valid form key. Use lower case letters, numbers and hyphens.");

        var versions = files.Where(f => f.Status != VersionStatus.Draft).OrderBy(f => f.Version).ToList();
        if (versions.Count == 0)
            throw new FormModelException($"'{key}' has no published or retired version, so there's nothing to generate.");

        var schemas = versions.Select(v => (v.Version, Schema: ReadSchema(key, v))).ToList();
        var fields = new List<FormField>();
        foreach (var name in schemas.SelectMany(s => Properties(s.Schema).Select(p => p.Key)).Distinct())
            fields.Add(BuildField(key, name, schemas));

        var formName = ToPascalCase(key);
        CheckNames(key, formName, fields);
        return new FormModel(key, formName, fields);
    }

    private static JsonObject ReadSchema(string key, TemplateFile version) =>
        (JsonNode.Parse(version.Json) as JsonObject)?["schema"] as JsonObject
        ?? throw new FormModelException($"{key} v{version.Version}: 'schema' must be an object.");

    private static IEnumerable<KeyValuePair<string, JsonNode?>> Properties(JsonObject schema) =>
        schema["properties"] as JsonObject ?? [];

    private static FormField BuildField(string key, string name, List<(int Version, JsonObject Schema)> schemas)
    {
        var uses = schemas
            .Where(s => s.Schema["properties"] is JsonObject properties && properties.ContainsKey(name))
            .Select(s => (s.Version, Property: s.Schema["properties"]![name] as JsonObject
                ?? throw new FormModelException($"{key} v{s.Version}: field '{name}' must be an object.")))
            .ToList();

        var types = uses.Select(u => (u.Version, Type: ClrType(key, u.Version, name, u.Property))).ToList();
        var conflict = types.FirstOrDefault(t => t.Type != types[0].Type);
        if (conflict.Type is not null)
        {
            throw new FormModelException(
                $"{key}: field '{name}' is {types[0].Type} in v{types[0].Version} but {conflict.Type} in v{conflict.Version}. " +
                "A field's type can't change between versions. Use a new field name or a new template key.");
        }

        var requiredEverywhere = schemas.All(s =>
            (s.Schema["required"] as JsonArray ?? []).Any(r => r?.ToString() == name));

        var maxLengths = uses.Select(u => u.Property["maxLength"]?.GetValue<int>()).ToList();
        var maxLength = maxLengths.All(m => m is not null) ? maxLengths.Max() : null;

        return new FormField(name, ToPascalCase(name), types[0].Type, !requiredEverywhere, maxLength);
    }

    private static string ClrType(string key, int version, string name, JsonObject property)
    {
        var type = property["type"] is JsonValue value ? value.ToString() : null;
        return (type, property["format"]?.ToString()) switch
        {
            ("string", "date") => "DateOnly",
            ("string", "date-time") => "DateTimeOffset",
            ("string", _) => "string",
            ("number", _) => "decimal",
            ("integer", _) => "long",
            ("boolean", _) => "bool",
            _ => throw new FormModelException(
                $"{key} v{version}: field '{name}' has type '{property["type"]?.ToJsonString()}'. " +
                "Only string, number, integer and boolean fields can become columns."),
        };
    }

    private static void CheckNames(string key, string name, List<FormField> fields)
    {
        foreach (var field in fields)
        {
            if (!Identifier().IsMatch(field.PropertyName))
                throw new FormModelException($"{key}: field '{field.JsonName}' can't be turned into a C# property name.");
            if (ReservedProperties.Contains(field.PropertyName) || field.PropertyName == name + "Submission" || field.PropertyName == name + "Dto")
                throw new FormModelException($"{key}: field '{field.JsonName}' clashes with the generated name '{field.PropertyName}'.");
        }

        var duplicate = fields.GroupBy(f => f.PropertyName, StringComparer.OrdinalIgnoreCase).FirstOrDefault(g => g.Count() > 1);
        if (duplicate is not null)
        {
            throw new FormModelException(
                $"{key}: fields {string.Join(" and ", duplicate.Select(f => $"'{f.JsonName}'"))} would have the same column name.");
        }
    }

    private static string ToPascalCase(string name) =>
        string.Concat(name.Split(['-', '_', ' '], StringSplitOptions.RemoveEmptyEntries)
            .Select(part => char.ToUpperInvariant(part[0]) + part[1..]));

    [GeneratedRegex("^[a-z][a-z0-9]*(-[a-z0-9]+)*$")]
    private static partial Regex FormKey();

    [GeneratedRegex("^[A-Za-z_][A-Za-z0-9_]*$")]
    private static partial Regex Identifier();
}
