using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;

namespace FormEngine.Templates;

public enum VersionStatus { Draft, Published, Retired }

public record TemplateFile(string Key, int Version, VersionStatus Status, string Json);

/// <summary>Reads templates laid out as {root}/{key}/v{version}.json.</summary>
public static partial class TemplateLoader
{
    public static IReadOnlyList<TemplateFile> LoadAll(string root) =>
        Directory.GetDirectories(root)
            .SelectMany(folder => Load(folder))
            .ToList();

    public static IReadOnlyList<TemplateFile> LoadForm(string root, string key)
    {
        var folder = Path.Combine(root, key);
        if (!Directory.Exists(folder))
            throw new InvalidDataException($"There is no template folder at {folder}.");
        return Load(folder);
    }

    private static List<TemplateFile> Load(string folder)
    {
        var key = Path.GetFileName(folder);
        return Directory.GetFiles(folder, "*.json")
            .Select(file => Read(key, file))
            .OrderBy(file => file.Version)
            .ToList();
    }

    private static TemplateFile Read(string key, string path)
    {
        var match = VersionFileName().Match(Path.GetFileName(path));
        if (!match.Success)
            throw new InvalidDataException($"{path}: template files must be named v1.json, v2.json and so on.");

        var json = File.ReadAllText(path);
        return new TemplateFile(key, int.Parse(match.Groups[1].Value), ReadStatus(path, json), json);
    }

    private static VersionStatus ReadStatus(string path, string json)
    {
        try
        {
            return JsonNode.Parse(json)?["status"]?.ToString() switch
            {
                "draft" => VersionStatus.Draft,
                "published" => VersionStatus.Published,
                "retired" => VersionStatus.Retired,
                var status => throw new InvalidDataException(
                    $"{path}: 'status' must be draft, published or retired, not '{status}'."),
            };
        }
        catch (JsonException ex)
        {
            throw new InvalidDataException($"{path}: the file isn't valid JSON: {ex.Message}", ex);
        }
    }

    [GeneratedRegex(@"^v([1-9][0-9]*)\.json$")]
    private static partial Regex VersionFileName();
}
