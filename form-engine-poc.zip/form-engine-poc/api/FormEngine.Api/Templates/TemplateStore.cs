using System.Reflection;
using FormEngine.Api.Forms;
using FormEngine.Templates;

namespace FormEngine.Api.Templates;

/// <summary>The templates loaded from disk at startup.</summary>
public class TemplateStore(IReadOnlyList<TemplateFile> files)
{
    public IReadOnlyList<TemplateFile> Files => files;

    public TemplateFile? Find(string key, int version) =>
        files.FirstOrDefault(file => file.Key == key && file.Version == version);

    public TemplateFile? FindPublished(string key, int? version) =>
        files.Where(file => file.Key == key && file.Status == VersionStatus.Published && (version is null || file.Version == version))
            .MaxBy(file => file.Version);

    public IReadOnlyList<TemplateFile> Versions(string key) =>
        files.Where(file => file.Key == key).OrderBy(file => file.Version).ToList();

    /// <summary>Finds anything that would make a form fail at runtime, so the API can refuse to start.</summary>
    public IReadOnlyList<string> FindProblems(PublishValidator validator, Assembly entityAssembly)
    {
        var entities = entityAssembly.GetTypes()
            .Select(type => type.GetCustomAttribute<FormEntityAttribute>())
            .OfType<FormEntityAttribute>()
            .ToDictionary(attribute => attribute.Key);

        var problems = new List<string>();
        foreach (var form in files.GroupBy(file => file.Key).Where(form => form.Any(file => file.Status != VersionStatus.Draft)))
        {
            foreach (var file in form.Where(file => file.Status != VersionStatus.Draft))
                problems.AddRange(validator.Validate(file.Json).Select(problem => $"{form.Key} v{file.Version}: {problem}"));

            var regenerate = $"Run scripts/generate-form.ps1 {form.Key}.";
            try
            {
                var model = FormModel.Build(form.Key, form);
                if (!entities.TryGetValue(form.Key, out var entity))
                    problems.Add($"{form.Key}: there is no generated code for this form. {regenerate}");
                else if (entity.Fingerprint != model.Fingerprint)
                    problems.Add($"{form.Key}: the generated code doesn't match the template's fields. {regenerate}");
            }
            catch (FormModelException ex)
            {
                problems.Add(ex.Message);
            }
        }
        return problems;
    }
}
