using System.Text.Json;
using System.Text.Json.Nodes;

namespace FormEngine.Api.Templates;

public record BehaviourBinding(string Trigger, string Behaviour, JsonObject? When, JsonObject Args);

/// <summary>The parsed form of a template version's JSON document.</summary>
public record TemplateDefinition(string? Title, JsonObject Schema, JsonObject UiSchema, IReadOnlyList<BehaviourBinding> Behaviours)
{
    /// <exception cref="FormatException">The document doesn't have the expected shape.</exception>
    public static TemplateDefinition Parse(string json)
    {
        try
        {
            var root = JsonNode.Parse(json) as JsonObject ?? throw new FormatException("The definition must be a JSON object.");
            var schema = root["schema"] as JsonObject ?? throw new FormatException("'schema' must be an object.");
            var uiSchema = root["uischema"] as JsonObject ?? throw new FormatException("'uischema' must be an object.");
            var bindings = (root["behaviours"] as JsonArray ?? []).Select(ParseBinding).ToList();
            return new TemplateDefinition(root["title"]?.GetValue<string>(), schema, uiSchema, bindings);
        }
        catch (Exception ex) when (ex is JsonException or InvalidOperationException)
        {
            throw new FormatException($"The definition isn't valid: {ex.Message}", ex);
        }
    }

    private static BehaviourBinding ParseBinding(JsonNode? node)
    {
        var binding = node as JsonObject ?? throw new FormatException("Each behaviour binding must be an object.");
        return new BehaviourBinding(
            binding["trigger"]?.GetValue<string>() ?? throw new FormatException("A behaviour binding has no 'trigger'."),
            binding["behaviour"]?.GetValue<string>() ?? throw new FormatException("A behaviour binding has no 'behaviour'."),
            binding["when"] as JsonObject,
            binding["args"] as JsonObject ?? []);
    }
}
