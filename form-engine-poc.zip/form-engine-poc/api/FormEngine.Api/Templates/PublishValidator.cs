using System.Text.Json;
using System.Text.Json.Nodes;
using FormEngine.Api.Behaviours;
using FormEngine.Api.Lookups;
using FormEngine.Api.Rules;

namespace FormEngine.Api.Templates;

/// <summary>Finds mistakes in a template when it's published, so they don't surface at runtime.</summary>
public class PublishValidator(BehaviourRegistry behaviours, LookupRegistry lookups)
{
    private static readonly string[] Effects = ["SHOW", "HIDE", "ENABLE", "DISABLE"];

    public IReadOnlyList<string> Validate(string json)
    {
        TemplateDefinition definition;
        try
        {
            definition = TemplateDefinition.Parse(json);
        }
        catch (FormatException ex)
        {
            return [ex.Message];
        }

        var errors = new List<string>();
        CheckSchema(definition, errors);
        CheckUiSchema(definition, errors);
        foreach (var binding in definition.Behaviours)
            CheckBinding(binding, definition.Schema, errors);
        return errors;
    }

    private static void CheckSchema(TemplateDefinition definition, List<string> errors)
    {
        try
        {
            JsonForm.BuildSchema(definition.Schema);
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            errors.Add($"'schema' isn't a valid JSON Schema: {ex.Message}");
        }
    }

    private void CheckUiSchema(TemplateDefinition definition, List<string> errors)
    {
        foreach (var element in UiSchema.Elements(definition.UiSchema))
        {
            if (element["rule"] is not JsonObject rule) continue;
            if (!Effects.Contains(rule["effect"]?.ToString()))
                errors.Add($"Unsupported rule effect '{rule["effect"]}'.");
            CheckCondition(rule["condition"] as JsonObject, definition.Schema, "A rule", errors);
        }

        var rootRequired = (definition.Schema["required"] as JsonArray ?? []).Select(r => r?.ToString()).ToHashSet();
        foreach (var control in UiSchema.Controls(definition.UiSchema))
        {
            var scope = control.Element["scope"]!.GetValue<string>();
            if (!ScopeExists(scope, definition.Schema))
                errors.Add($"Control scope '{scope}' isn't in the schema.");

            var canBeHidden = control.Rules.Any(r => r["effect"]?.ToString() is "SHOW" or "HIDE");
            if (canBeHidden && control.DataPath.Length == 1 && rootRequired.Contains(control.DataPath[0]))
                errors.Add($"'{control.DataPath[0]}' can be hidden, so it must be conditionally required, not in the root 'required' list.");

            CheckLookup(control, definition.Schema, errors);
        }
    }

    private void CheckLookup(UiControl control, JsonObject schema, List<string> errors)
    {
        var options = control.Element["options"] as JsonObject;
        var lookup = options?["lookup"]?.ToString();
        if (lookup is null) return;

        if (!lookups.Exists(lookup))
            errors.Add($"Unknown lookup '{lookup}'.");

        foreach (var (name, scope) in options!["lookupParams"] as JsonObject ?? [])
        {
            if (scope?.GetValueKind() != JsonValueKind.String || !ScopeExists(scope.GetValue<string>(), schema))
                errors.Add($"Lookup parameter '{name}' has a scope that isn't in the schema.");
        }
    }

    private void CheckBinding(BehaviourBinding binding, JsonObject schema, List<string> errors)
    {
        if (binding.Trigger is not (Triggers.BeforeSave or Triggers.AfterSave))
            errors.Add($"Unknown trigger '{binding.Trigger}' on behaviour '{binding.Behaviour}'.");

        if (binding.When is not null)
            CheckCondition(binding.When, schema, $"Behaviour '{binding.Behaviour}'", errors);

        var behaviour = behaviours.Find(binding.Behaviour);
        if (behaviour is null)
        {
            errors.Add($"Unknown behaviour '{binding.Behaviour}'.");
            return;
        }

        foreach (var error in SchemaValidator.Validate(behaviour.ArgsSchema.AsObject(), binding.Args))
            errors.Add($"Behaviour '{binding.Behaviour}' args are invalid at '{error.Path}': {error.Message}");
    }

    /// <summary>
    /// Only scope + schema conditions are supported. failWhenUndefined is required because Ajv on
    /// the client and the evaluator here could otherwise treat a missing value differently.
    /// </summary>
    private static void CheckCondition(JsonObject? condition, JsonObject schema, string owner, List<string> errors)
    {
        if (condition is null || condition["type"] is not null || condition["scope"] is null || condition["schema"] is null)
        {
            errors.Add($"{owner} has an unsupported condition: only scope + schema conditions are supported.");
            return;
        }

        if (condition["failWhenUndefined"]?.GetValueKind() != JsonValueKind.True)
            errors.Add($"{owner} has a condition that doesn't set failWhenUndefined to true.");
        if (!ScopeExists(condition["scope"]!.ToString(), schema))
            errors.Add($"Condition scope '{condition["scope"]}' isn't in the schema.");
    }

    private static bool ScopeExists(string scope, JsonObject schema)
    {
        JsonNode? current = schema;
        foreach (var segment in scope.TrimStart('#').Split('/', StringSplitOptions.RemoveEmptyEntries))
        {
            current = (current as JsonObject)?[segment];
            if (current is null) return false;
        }
        return true;
    }
}
