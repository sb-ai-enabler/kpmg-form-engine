using System.Reflection;
using FormEngine.Api.Forms;
using Microsoft.EntityFrameworkCore;

namespace FormEngine.Api.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        var entities = Assembly.GetExecutingAssembly().GetTypes()
            .Where(type => type.GetCustomAttribute<FormEntityAttribute>() is not null);

        foreach (var entity in entities)
            modelBuilder.Entity(entity);
    }
}
