using System.Text.Json.Nodes;

namespace FormEngine.Api.Forms;

/// <summary>Marks a generated entity. The fingerprint identifies the template fields it was generated from.</summary>
[AttributeUsage(AttributeTargets.Class, Inherited = false)]
public sealed class FormEntityAttribute(string key, string fingerprint) : Attribute
{
    public string Key { get; } = key;
    public string Fingerprint { get; } = fingerprint;
}

/// <summary>The columns every form's table has, in addition to the template's fields.</summary>
public abstract class FormSubmission
{
    public int Id { get; set; }
    public int TemplateVersion { get; set; }
    public DateTime CreatedAt { get; set; }
    public string Outputs { get; set; } = "{}";
    public string BehaviourRuns { get; set; } = "[]";

    public SubmissionResponse<TData> ToResponse<TData>(string key, TData data) => new(
        Id,
        key,
        TemplateVersion,
        data,
        JsonNode.Parse(Outputs),
        JsonNode.Parse(BehaviourRuns),
        DateTime.SpecifyKind(CreatedAt, DateTimeKind.Utc));
}

public record SubmissionResponse<TData>(
    int Id,
    string TemplateKey,
    int Version,
    TData Data,
    JsonNode? Outputs,
    JsonNode? BehaviourRuns,
    DateTime CreatedAt);
