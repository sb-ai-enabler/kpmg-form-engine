using FormEngine.Api.Behaviours;
using Microsoft.AspNetCore.Mvc;

namespace FormEngine.Api.Forms;

public static class BindingErrors
{
    /// <summary>Reports a body that doesn't fit a form's DTO, such as text in a number field or an unknown field, as field errors.</summary>
    public static IActionResult ToActionResult(ActionContext context)
    {
        var errors = context.ModelState
            .Where(entry => entry.Value!.Errors.Count > 0)
            .SelectMany(entry => entry.Value!.Errors.Select(error => new FieldError(ToPointer(entry.Key), error.ErrorMessage)))
            .ToList();

        // A JSON error also adds "The data field is required." for the parameter, which only repeats it.
        var fieldErrors = errors.Where(error => error.Path != "").ToList();
        return new UnprocessableEntityObjectResult(new { errors = fieldErrors.Count > 0 ? fieldErrors : errors });
    }

    // System.Text.Json reports paths such as "$.amount", and the form expects JSON pointers such as "/amount".
    private static string ToPointer(string key) =>
        key.StartsWith("$.") ? "/" + key[2..].Replace('.', '/') : "";
}

public abstract record SubmissionFailure
{
    public record VersionNotFound : SubmissionFailure;
    public record NotPublished(string Message) : SubmissionFailure;
    public record Rejected(IReadOnlyList<FieldError> Errors) : SubmissionFailure;
}

public record SubmissionResult<T>(T? Value, SubmissionFailure? Failure)
{
    public static SubmissionResult<T> Saved(T value) => new(value, null);
    public static SubmissionResult<T> Failed(SubmissionFailure failure) => new(default, failure);

    public IActionResult ToActionResult(ControllerBase controller, Func<T, string> location) => Failure switch
    {
        null => controller.Created(location(Value!), Value),
        SubmissionFailure.VersionNotFound => controller.NotFound(),
        SubmissionFailure.NotPublished notPublished => controller.Conflict(new { error = notPublished.Message }),
        SubmissionFailure.Rejected rejected => controller.UnprocessableEntity(new { errors = rejected.Errors }),
        _ => throw new InvalidOperationException("Unknown submission failure."),
    };
}
