using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using FormEngine.Api.Behaviours;
using FormEngine.Api.Lookups;
using FormEngine.Api.Rules;
using FormEngine.Api.Templates;
using FormEngine.Templates;

namespace FormEngine.Api.Forms;

public record BehaviourRun(string Behaviour, string Trigger, string Status, string? Error = null);

/// <summary>A submission that has passed validation and its beforeSave behaviours, and is ready to store.</summary>
public record PreparedSubmission(
    string Key,
    int Version,
    TemplateDefinition Definition,
    JsonObject Data,
    JsonObject Outputs,
    List<BehaviourRun> Runs);

public record PrepareResult(PreparedSubmission? Submission, SubmissionFailure? Failure);

public record CompletedSubmission(string Outputs, string BehaviourRuns);

/// <summary>The parts of handling a submission that are the same for every form. Generated handlers call this around their save.</summary>
public class SubmissionProcessor(
    TemplateStore templates,
    BehaviourRegistry behaviours,
    LookupRegistry lookups,
    ILogger<SubmissionProcessor> logger)
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    // Null DTO properties are left out, so the template's schema treats them as missing.
    private static readonly JsonSerializerOptions DataOptions = new() { DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull };

    /// <summary>Validates a form's typed DTO against the template, using the same checks as the JSON it came from.</summary>
    public Task<PrepareResult> PrepareAsync<TData>(string key, int version, TData submitted, CancellationToken ct) =>
        PrepareAsync(key, version, JsonSerializer.SerializeToNode(submitted, DataOptions)!.AsObject(), ct);

    public async Task<PrepareResult> PrepareAsync(string key, int version, JsonObject submitted, CancellationToken ct)
    {
        var template = templates.Find(key, version);
        if (template is null)
            return new PrepareResult(null, new SubmissionFailure.VersionNotFound());
        if (template.Status != VersionStatus.Published)
            return new PrepareResult(null, new SubmissionFailure.NotPublished($"Version {version} is {template.Status}."));

        var definition = TemplateDefinition.Parse(template.Json);
        var data = UiSchema.Prune(definition.UiSchema, submitted);

        var errors = new List<FieldError>(SchemaValidator.Validate(definition.Schema, data));
        errors.AddRange(await ValidateLookupsAsync(definition, data, ct));
        if (errors.Count > 0)
            return new PrepareResult(null, new SubmissionFailure.Rejected(errors));

        var outputs = new JsonObject();
        var runs = new List<BehaviourRun>();

        foreach (var binding in Bindings(definition, Triggers.BeforeSave))
        {
            if (!ShouldRun(binding, data, runs)) continue;

            var context = new BehaviourContext(key, version, binding.Trigger, data, binding.Args, null);
            var result = await GetBehaviour(binding).ExecuteAsync(context, ct);
            errors.AddRange(result.FieldErrors);
            MergeOutputs(outputs, result);
            runs.Add(new BehaviourRun(binding.Behaviour, binding.Trigger, result.FieldErrors.Count > 0 ? "Rejected" : "Succeeded"));
        }
        if (errors.Count > 0)
            return new PrepareResult(null, new SubmissionFailure.Rejected(errors));

        return new PrepareResult(new PreparedSubmission(key, version, definition, data, outputs, runs), null);
    }

    public async Task<CompletedSubmission> CompleteAsync(PreparedSubmission submission, int submissionId)
    {
        foreach (var binding in Bindings(submission.Definition, Triggers.AfterSave))
        {
            if (ShouldRun(binding, submission.Data, submission.Runs))
                await RunAfterSaveAsync(binding, submission, submissionId);
        }

        return new CompletedSubmission(submission.Outputs.ToJsonString(), JsonSerializer.Serialize(submission.Runs, JsonOptions));
    }

    private async Task RunAfterSaveAsync(BehaviourBinding binding, PreparedSubmission submission, int submissionId)
    {
        try
        {
            var context = new BehaviourContext(submission.Key, submission.Version, binding.Trigger, submission.Data, binding.Args, submissionId);
            var result = await GetBehaviour(binding).ExecuteAsync(context, CancellationToken.None);
            MergeOutputs(submission.Outputs, result);
            submission.Runs.Add(new BehaviourRun(binding.Behaviour, binding.Trigger, "Succeeded"));
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Behaviour {Behaviour} failed for submission {SubmissionId}", binding.Behaviour, submissionId);
            submission.Runs.Add(new BehaviourRun(binding.Behaviour, binding.Trigger, "Failed", ex.Message));
        }
    }

    private async Task<List<FieldError>> ValidateLookupsAsync(TemplateDefinition definition, JsonObject data, CancellationToken ct)
    {
        var errors = new List<FieldError>();
        foreach (var control in UiSchema.Controls(definition.UiSchema))
        {
            var options = control.Element["options"] as JsonObject;
            if (options?["lookup"]?.ToString() is not { } lookup) continue;
            if (!JsonForm.TryGetValue(data, control.DataPath, out var value) || value is null) continue;

            var parameters = new Dictionary<string, string?>();
            foreach (var (name, scope) in options["lookupParams"] as JsonObject ?? [])
            {
                JsonForm.TryGetValue(data, JsonForm.ScopeToDataPath(scope!.GetValue<string>()), out var parameter);
                parameters[name] = parameter?.ToString();
            }

            var allowed = await lookups.GetOptionsAsync(lookup, parameters, ct);
            if (allowed.All(option => option.Value != value.ToString()))
                errors.Add(new FieldError(JsonForm.ToPointer(control.DataPath), "This isn't an available option"));
        }
        return errors;
    }

    private IBehaviour GetBehaviour(BehaviourBinding binding) =>
        behaviours.Find(binding.Behaviour)
        ?? throw new InvalidOperationException($"Behaviour '{binding.Behaviour}' isn't registered.");

    private static IEnumerable<BehaviourBinding> Bindings(TemplateDefinition definition, string trigger) =>
        definition.Behaviours.Where(b => b.Trigger == trigger);

    private static bool ShouldRun(BehaviourBinding binding, JsonObject data, List<BehaviourRun> runs)
    {
        if (binding.When is null || RuleEvaluator.Evaluate(binding.When, data)) return true;
        runs.Add(new BehaviourRun(binding.Behaviour, binding.Trigger, "Skipped"));
        return false;
    }

    private static void MergeOutputs(JsonObject outputs, BehaviourResult result)
    {
        foreach (var (name, value) in result.Outputs)
            outputs[name] = value?.DeepClone();
    }
}
