using System.Text.Json;
using System.Text.Json.Nodes;
using Json.Schema;

namespace FormEngine.Api.Rules;

/// <summary>Helpers for JSON Schema building and for JsonForms scopes and data paths.</summary>
public static class JsonForm
{
    public static JsonSchema BuildSchema(JsonNode? schema) =>
        JsonSchema.Build(JsonSerializer.SerializeToElement(schema), new BuildOptions { SchemaRegistry = new SchemaRegistry() });

    /// <summary>Converts "#/properties/a/properties/b" to ["a", "b"].</summary>
    public static string[] ScopeToDataPath(string scope) =>
        scope.TrimStart('#').Split('/', StringSplitOptions.RemoveEmptyEntries)
            .Where((_, index) => index % 2 == 1)
            .ToArray();

    public static string ToPointer(IEnumerable<string> path) => string.Concat(path.Select(segment => "/" + segment));

    public static bool TryGetValue(JsonObject data, IReadOnlyList<string> path, out JsonNode? value)
    {
        value = data;
        foreach (var segment in path)
        {
            if (value is not JsonObject current || !current.TryGetPropertyValue(segment, out value))
            {
                value = null;
                return false;
            }
        }
        return true;
    }

    public static void Remove(JsonObject data, IReadOnlyList<string> path)
    {
        if (path.Count == 0) return;
        if (TryGetValue(data, path.Take(path.Count - 1).ToArray(), out var parent) && parent is JsonObject parentObject)
            parentObject.Remove(path[^1]);
    }
}
