using System.Text.Json.Nodes;

namespace FormEngine.Api.Rules;

/// <summary>A control in the UI schema, with its own rule and those of its parent layouts.</summary>
public record UiControl(JsonObject Element, string[] DataPath, IReadOnlyList<JsonObject> Rules);

public static class UiSchema
{
    public static IEnumerable<JsonObject> Elements(JsonObject element)
    {
        yield return element;
        if (element["elements"] is not JsonArray children) yield break;
        foreach (var child in children.OfType<JsonObject>())
        foreach (var descendant in Elements(child))
            yield return descendant;
    }

    public static IEnumerable<UiControl> Controls(JsonObject uiSchema) => Controls(uiSchema, []);

    /// <summary>
    /// Returns a copy of the data without values for hidden or disabled controls. All rules are
    /// evaluated against the submitted data, in a single pass, to match what the client displayed.
    /// </summary>
    public static JsonObject Prune(JsonObject uiSchema, JsonObject data)
    {
        var pruned = data.DeepClone().AsObject();
        foreach (var control in Controls(uiSchema))
        {
            if (!RuleEvaluator.IsActive(control.Rules, data))
                JsonForm.Remove(pruned, control.DataPath);
        }
        return pruned;
    }

    private static IEnumerable<UiControl> Controls(JsonObject element, IReadOnlyList<JsonObject> inheritedRules)
    {
        var rules = element["rule"] is JsonObject rule ? [.. inheritedRules, rule] : inheritedRules;
        if (element["type"]?.GetValue<string>() == "Control" && element["scope"] is JsonValue scope)
            yield return new UiControl(element, JsonForm.ScopeToDataPath(scope.GetValue<string>()), rules);

        if (element["elements"] is not JsonArray children) yield break;
        foreach (var child in children.OfType<JsonObject>())
        foreach (var control in Controls(child, rules))
            yield return control;
    }
}
