using System.Text.Json;
using System.Text.Json.Nodes;
using FormEngine.Api.Behaviours;
using Json.Schema;

namespace FormEngine.Api.Rules;

/// <summary>Validates data against a JSON Schema and reports errors against individual fields.</summary>
public static class SchemaValidator
{
    private static readonly EvaluationOptions Options = new()
    {
        OutputFormat = OutputFormat.Hierarchical,
        RequireFormatValidation = true,
    };

    public static IReadOnlyList<FieldError> Validate(JsonObject schema, JsonObject data)
    {
        var results = JsonForm.BuildSchema(schema).Evaluate(JsonSerializer.SerializeToElement(data), Options);
        var errors = new List<FieldError>();
        Collect(results, schema, data, errors);
        return errors.Distinct().ToList();
    }

    private static void Collect(EvaluationResults node, JsonObject schema, JsonObject data, List<FieldError> errors)
    {
        if (node.IsValid) return;

        foreach (var (keyword, message) in node.Errors ?? new Dictionary<string, string>())
        {
            // These only say that a branch failed. The branch's own results give the field errors.
            if (keyword is "if" or "then" or "else" or "properties") continue;

            if (keyword == "required")
                errors.AddRange(MissingFields(node, schema, data, message));
            else
                errors.Add(new FieldError(node.InstanceLocation.ToString(), message));
        }

        foreach (var detail in node.Details ?? [])
        {
            if (!IsNonAssertingBranch(detail.EvaluationPath.ToString()))
                Collect(detail, schema, data, errors);
        }
    }

    /// <summary>A failing "if" or "not" subschema isn't itself a validation error.</summary>
    private static bool IsNonAssertingBranch(string evaluationPath)
    {
        var segments = evaluationPath.Split('/');
        return segments[^1] is "if" or "not" && (segments.Length < 2 || segments[^2] != "properties");
    }

    /// <summary>Reports each missing property on its own path, so the error can be shown on that field.</summary>
    private static IEnumerable<FieldError> MissingFields(EvaluationResults node, JsonObject schema, JsonObject data, string message)
    {
        var instancePath = node.InstanceLocation.ToString();
        var required = (Navigate(schema, node.EvaluationPath.ToString()) as JsonObject)?["required"] as JsonArray;
        if (required is null || Navigate(data, instancePath) is not JsonObject instance)
            return [new FieldError(instancePath, message)];

        return required
            .Select(name => name!.GetValue<string>())
            .Where(name => !instance.ContainsKey(name))
            .Select(name => new FieldError($"{instancePath}/{name}", "This field is required"));
    }

    private static JsonNode? Navigate(JsonNode root, string pointer)
    {
        var current = root;
        foreach (var segment in pointer.Split('/', StringSplitOptions.RemoveEmptyEntries))
            current = (current as JsonObject)?[segment.Replace("~1", "/").Replace("~0", "~")];
        return current;
    }
}
