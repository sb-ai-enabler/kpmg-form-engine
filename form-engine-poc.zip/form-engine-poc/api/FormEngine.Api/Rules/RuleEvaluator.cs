using System.Text.Json;
using System.Text.Json.Nodes;

namespace FormEngine.Api.Rules;

/// <summary>Server-side evaluation of JsonForms scope + schema conditions, used for both UI rules and behaviour "when".</summary>
public static class RuleEvaluator
{
    public static bool Evaluate(JsonObject condition, JsonObject data)
    {
        var path = JsonForm.ScopeToDataPath(condition["scope"]!.GetValue<string>());
        if (!JsonForm.TryGetValue(data, path, out var value))
            return condition["failWhenUndefined"]?.GetValue<bool>() != true;

        return JsonForm.BuildSchema(condition["schema"])
            .Evaluate(JsonSerializer.SerializeToElement(value))
            .IsValid;
    }

    /// <summary>Returns false if any of the rules leaves the element hidden or disabled.</summary>
    public static bool IsActive(IEnumerable<JsonObject> rules, JsonObject data) =>
        rules.All(rule =>
        {
            var conditionMet = Evaluate(rule["condition"]!.AsObject(), data);
            return rule["effect"]!.GetValue<string>() is "SHOW" or "ENABLE" ? conditionMet : !conditionMet;
        });
}
