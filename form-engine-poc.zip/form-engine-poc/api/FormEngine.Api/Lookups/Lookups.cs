namespace FormEngine.Api.Lookups;

public record LookupOption(string Value, string Label);

public interface ILookupProvider
{
    string Name { get; }
    Task<IReadOnlyList<LookupOption>> GetOptionsAsync(IReadOnlyDictionary<string, string?> parameters, CancellationToken ct);
}

public class LookupRegistry(IEnumerable<ILookupProvider> providers)
{
    private readonly Dictionary<string, ILookupProvider> _providers = providers.ToDictionary(p => p.Name);

    public bool Exists(string name) => _providers.ContainsKey(name);

    public Task<IReadOnlyList<LookupOption>> GetOptionsAsync(
        string name, IReadOnlyDictionary<string, string?> parameters, CancellationToken ct) =>
        _providers[name].GetOptionsAsync(parameters, ct);
}

public class DepartmentsLookup : ILookupProvider
{
    public string Name => "departments";

    public Task<IReadOnlyList<LookupOption>> GetOptionsAsync(IReadOnlyDictionary<string, string?> parameters, CancellationToken ct) =>
        Task.FromResult<IReadOnlyList<LookupOption>>(
        [
            new("travel", "Travel"),
            new("engineering", "Engineering"),
            new("marketing", "Marketing"),
        ]);
}

public class CostCentresLookup : ILookupProvider
{
    private static readonly Dictionary<string, LookupOption[]> CostCentres = new()
    {
        ["travel"] = [new("TR-100", "TR-100 Domestic travel"), new("TR-200", "TR-200 International travel")],
        ["engineering"] = [new("EN-100", "EN-100 Platform"), new("EN-200", "EN-200 Product")],
        ["marketing"] = [new("MK-100", "MK-100 Campaigns")],
    };

    public string Name => "costCentres";

    public Task<IReadOnlyList<LookupOption>> GetOptionsAsync(IReadOnlyDictionary<string, string?> parameters, CancellationToken ct)
    {
        var department = parameters.GetValueOrDefault("department");
        return Task.FromResult<IReadOnlyList<LookupOption>>(
            department is not null && CostCentres.TryGetValue(department, out var options) ? options : []);
    }
}
