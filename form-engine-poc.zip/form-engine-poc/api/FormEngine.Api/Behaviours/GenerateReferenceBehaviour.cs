using System.Text.Json.Nodes;

namespace FormEngine.Api.Behaviours;

/// <summary>Creates a reference such as EXP-2026-000123 from the saved submission's id.</summary>
public class GenerateReferenceBehaviour : IBehaviour
{
    public string Key => "generate-reference";

    public JsonNode ArgsSchema { get; } = JsonNode.Parse("""
        {
          "type": "object",
          "properties": { "prefix": { "type": "string", "minLength": 1 } },
          "required": ["prefix"],
          "additionalProperties": false
        }
        """)!;

    public Task<BehaviourResult> ExecuteAsync(BehaviourContext ctx, CancellationToken ct)
    {
        if (ctx.SubmissionId is not { } id)
            throw new InvalidOperationException($"{Key} needs a saved submission, so it must run on {Triggers.AfterSave}.");

        var prefix = ctx.Args["prefix"]!.GetValue<string>();
        return Task.FromResult(BehaviourResult.Output("reference", $"{prefix}-{DateTime.UtcNow.Year}-{id:D6}"));
    }
}
