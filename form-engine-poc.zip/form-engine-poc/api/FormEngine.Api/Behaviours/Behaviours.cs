using System.Text.Json.Nodes;

namespace FormEngine.Api.Behaviours;

public static class Triggers
{
    public const string BeforeSave = "beforeSave";
    public const string AfterSave = "afterSave";
}

public record FieldError(string Path, string Message);

public record BehaviourContext(
    string TemplateKey,
    int Version,
    string Trigger,
    JsonObject Data,
    JsonObject Args,
    int? SubmissionId);

public record BehaviourResult(IReadOnlyList<FieldError> FieldErrors, IReadOnlyDictionary<string, JsonNode?> Outputs)
{
    public static readonly BehaviourResult Empty = new([], new Dictionary<string, JsonNode?>());

    public static BehaviourResult Error(string path, string message) => Empty with { FieldErrors = [new(path, message)] };

    public static BehaviourResult Output(string name, JsonNode? value) =>
        Empty with { Outputs = new Dictionary<string, JsonNode?> { [name] = value } };
}

/// <summary>A reusable block of code. Anything specific to a template comes from the args.</summary>
public interface IBehaviour
{
    string Key { get; }
    JsonNode ArgsSchema { get; }
    Task<BehaviourResult> ExecuteAsync(BehaviourContext ctx, CancellationToken ct);
}

public class BehaviourRegistry(IEnumerable<IBehaviour> behaviours)
{
    private readonly Dictionary<string, IBehaviour> _behaviours = behaviours.ToDictionary(b => b.Key);

    public IBehaviour? Find(string key) => _behaviours.GetValueOrDefault(key);
}
