using System.Text.Json.Nodes;

namespace FormEngine.Api.Behaviours;

/// <summary>Blocks the save when a numeric field is over the configured maximum.</summary>
public class FieldLimitBehaviour : IBehaviour
{
    public string Key => "field-limit";

    public JsonNode ArgsSchema { get; } = JsonNode.Parse("""
        {
          "type": "object",
          "properties": {
            "field": { "type": "string", "minLength": 1 },
            "max": { "type": "number" },
            "message": { "type": "string" }
          },
          "required": ["field", "max"],
          "additionalProperties": false
        }
        """)!;

    public Task<BehaviourResult> ExecuteAsync(BehaviourContext ctx, CancellationToken ct)
    {
        var field = ctx.Args["field"]!.GetValue<string>();
        var max = ctx.Args["max"]!.GetValue<decimal>();
        var path = "/" + field;

        if (!ctx.Data.TryGetPropertyValue(field, out var node) || node is null)
            return Task.FromResult(BehaviourResult.Empty);

        if (node is not JsonValue value || !value.TryGetValue<decimal>(out var number))
            return Task.FromResult(BehaviourResult.Error(path, "Must be a number"));

        return Task.FromResult(number > max
            ? BehaviourResult.Error(path, ctx.Args["message"]?.GetValue<string>() ?? $"Cannot exceed {max}")
            : BehaviourResult.Empty);
    }
}
