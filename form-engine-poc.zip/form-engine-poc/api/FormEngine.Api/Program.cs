using System.Reflection;
using System.Text.Json.Serialization;
using FormEngine.Api.Behaviours;
using FormEngine.Api.Data;
using FormEngine.Api.Features;
using FormEngine.Api.Forms;
using FormEngine.Api.Lookups;
using FormEngine.Api.Templates;
using FormEngine.Templates;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("Default")));
builder.Services.AddProblemDetails();
builder.Services.AddCors(options => options.AddDefaultPolicy(policy =>
    policy.WithOrigins("http://localhost:5173").AllowAnyHeader().AllowAnyMethod()));
builder.Services.AddControllers()
    .AddJsonOptions(options => options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull)
    .ConfigureApiBehaviorOptions(options => options.InvalidModelStateResponseFactory = BindingErrors.ToActionResult);

builder.Services.AddSingleton<IBehaviour, FieldLimitBehaviour>();
builder.Services.AddSingleton<IBehaviour, GenerateReferenceBehaviour>();
builder.Services.AddSingleton<BehaviourRegistry>();
builder.Services.AddSingleton<ILookupProvider, DepartmentsLookup>();
builder.Services.AddSingleton<ILookupProvider, CostCentresLookup>();
builder.Services.AddSingleton<LookupRegistry>();
builder.Services.AddSingleton<PublishValidator>();
builder.Services.AddSingleton(new TemplateStore(
    TemplateLoader.LoadAll(Path.Combine(builder.Environment.ContentRootPath, "FormTemplates"))));
builder.Services.AddScoped<SubmissionProcessor>();
builder.Services.AddFormFeatures();

var app = builder.Build();

app.UseExceptionHandler();
app.UseCors();

var problems = app.Services.GetRequiredService<TemplateStore>()
    .FindProblems(app.Services.GetRequiredService<PublishValidator>(), Assembly.GetExecutingAssembly());
if (problems.Count > 0)
    throw new InvalidOperationException($"The form templates have problems:{Environment.NewLine}{string.Join(Environment.NewLine, problems)}");

using (var scope = app.Services.CreateScope())
{
    await scope.ServiceProvider.GetRequiredService<AppDbContext>().Database.MigrateAsync();
}

var forms = app.MapGroup("/api/forms/{key}");

forms.MapGet("/", (string key, int? version, TemplateStore templates) =>
{
    var match = templates.FindPublished(key, version);
    if (match is null) return Results.NotFound();

    // Behaviours stay on the server: the browser only needs what it takes to render the form.
    var definition = TemplateDefinition.Parse(match.Json);
    return Results.Ok(new { key, match.Version, definition.Title, definition.Schema, uischema = definition.UiSchema });
});

forms.MapGet("/versions", (string key, TemplateStore templates) =>
{
    var versions = templates.Versions(key);
    return versions.Count == 0
        ? Results.NotFound()
        : Results.Ok(versions.Select(v => new { v.Version, Status = v.Status.ToString() }));
});

app.MapGet("/api/lookups/{name}", async (string name, HttpRequest request, LookupRegistry lookups, CancellationToken ct) =>
{
    if (!lookups.Exists(name)) return Results.NotFound();
    var parameters = request.Query.ToDictionary(q => q.Key, q => (string?)q.Value.ToString());
    return Results.Ok(await lookups.GetOptionsAsync(name, parameters, ct));
});

app.MapControllers();

app.Run();

public partial class Program;
