import type { JsonSchema, UISchemaElement } from '@jsonforms/core';

const baseUrl = import.meta.env.VITE_API_URL ?? 'http://localhost:5264';

export interface FormTemplate {
  key: string;
  version: number;
  title?: string;
  schema: JsonSchema;
  uischema: UISchemaElement;
}

export interface TemplateVersion {
  version: number;
  status: 'Draft' | 'Published' | 'Retired';
}

export interface LookupOption {
  value: string;
  label: string;
}

export interface FieldError {
  path: string;
  message: string;
}

export interface BehaviourRun {
  behaviour: string;
  trigger: string;
  status: string;
  error?: string;
}

export interface SavedSubmission {
  id: number;
  version: number;
  outputs: Record<string, unknown>;
  behaviourRuns: BehaviourRun[];
}

export type SubmitResult =
  | { kind: 'saved'; submission: SavedSubmission }
  | { kind: 'rejected'; errors: FieldError[] };

async function getJson<T>(path: string, signal?: AbortSignal): Promise<T> {
  const response = await fetch(`${baseUrl}${path}`, { signal });
  if (!response.ok) throw new Error(`Request failed with status ${response.status}`);
  return response.json();
}

export const getForm = (key: string, version: number | undefined, signal?: AbortSignal) =>
  getJson<FormTemplate>(`/api/forms/${key}${version ? `?version=${version}` : ''}`, signal);

export const getVersions = (key: string, signal?: AbortSignal) =>
  getJson<TemplateVersion[]>(`/api/forms/${key}/versions`, signal);

export const getLookup = (name: string, params: Record<string, string>, signal?: AbortSignal) =>
  getJson<LookupOption[]>(`/api/lookups/${name}?${new URLSearchParams(params)}`, signal);

export async function submitForm(key: string, version: number, data: unknown): Promise<SubmitResult> {
  const response = await fetch(`${baseUrl}/api/forms/${key}/versions/${version}/submissions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

  if (response.status === 422) {
    const body: { errors: FieldError[] } = await response.json();
    return { kind: 'rejected', errors: body.errors };
  }
  if (!response.ok) throw new Error(`Submit failed with status ${response.status}`);
  return { kind: 'saved', submission: await response.json() };
}
