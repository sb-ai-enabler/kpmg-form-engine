import { useEffect, useMemo, useRef, useState } from 'react';
import type { ErrorObject } from 'ajv';
import { createAjv, isControl, isEnabled, isVisible, toDataPath, type Layout, type UISchemaElement } from '@jsonforms/core';
import { JsonForms } from '@jsonforms/react';
import { materialCells, materialRenderers } from '@jsonforms/material-renderers';
import {
  Alert,
  Box,
  Button,
  CircularProgress,
  Container,
  MenuItem,
  Paper,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import { getForm, getVersions, submitForm, type FieldError, type FormTemplate, type SavedSubmission, type TemplateVersion } from './api';
import ApiSelectControl, { apiSelectTester } from './renderers/ApiSelectControl';

const renderers = [...materialRenderers, { tester: apiSelectTester, renderer: ApiSelectControl }];

// JsonForms text and number inputs report changes after about 300ms, so Submit has to wait for the last edit.
const inputDebounceMs = 350;

const ajv = createAjv();

const inactiveControls = (element: UISchemaElement, data: unknown, parentInactive = false): string[] => {
  const inactive = parentInactive || !isVisible(element, data, '', ajv, undefined) || !isEnabled(element, data, '', ajv, undefined);
  const own = inactive && isControl(element) ? [toDataPath(element.scope)] : [];
  const children = (element as Layout).elements ?? [];
  return [...own, ...children.flatMap((child) => inactiveControls(child, data, inactive))];
};

// Matches the server, which ignores hidden and disabled fields. They can still hold old invalid
// values, and the user has no way to correct those.
const isValidForSubmit = ({ schema, uischema }: FormTemplate, data: object) => {
  const active = JSON.parse(JSON.stringify(data));
  for (const path of inactiveControls(uischema, data)) {
    const segments = path.split('.');
    const parent = segments.slice(0, -1).reduce((current, segment) => current?.[segment], active);
    if (parent) delete parent[segments[segments.length - 1]];
  }
  return ajv.validate(schema, active);
};

const toAjvError = ({ path, message }: FieldError): ErrorObject => ({
  instancePath: path,
  message,
  schemaPath: '',
  keyword: 'server',
  params: {},
});

export default function FormPage({ formKey }: { formKey: string }) {
  const [versions, setVersions] = useState<TemplateVersion[]>([]);
  const [selectedVersion, setSelectedVersion] = useState<number>();
  const [form, setForm] = useState<FormTemplate>();
  const [data, setData] = useState<object>({});
  const [serverErrors, setServerErrors] = useState<FieldError[]>([]);
  const [blocked, setBlocked] = useState(false);
  const [showErrors, setShowErrors] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [saved, setSaved] = useState<SavedSubmission>();
  const [failure, setFailure] = useState<string>();
  const dataJson = useRef(JSON.stringify(data));

  useEffect(() => {
    const controller = new AbortController();
    getVersions(formKey, controller.signal)
      .then(setVersions)
      .catch((error: unknown) => {
        if (!controller.signal.aborted) setFailure(String(error));
      });
    return () => controller.abort();
  }, [formKey]);

  useEffect(() => {
    const controller = new AbortController();
    getForm(formKey, selectedVersion, controller.signal)
      .then(setForm)
      .catch((error: unknown) => {
        if (!controller.signal.aborted) setFailure(String(error));
      });
    return () => controller.abort();
  }, [formKey, selectedVersion]);

  const additionalErrors = useMemo(() => serverErrors.map(toAjvError), [serverErrors]);

  const handleFormChange = (next: unknown) => {
    const nextJson = JSON.stringify(next);
    if (nextJson === dataJson.current) return;
    dataJson.current = nextJson;
    setData(next as object);
    setServerErrors([]);
    setBlocked(false);
    setSaved(undefined);
  };

  const changeVersion = (version: number) => {
    setSelectedVersion(version);
    setServerErrors([]);
    setBlocked(false);
    setSaved(undefined);
    setFailure(undefined);
  };

  const reset = () => {
    dataJson.current = '{}';
    setData({});
    setServerErrors([]);
    setBlocked(false);
    setShowErrors(false);
    setSaved(undefined);
    setFailure(undefined);
  };

  const submit = async () => {
    if (!form) return;
    setSubmitting(true);
    setShowErrors(true);
    setFailure(undefined);
    setSaved(undefined);
    try {
      await new Promise((resolve) => setTimeout(resolve, inputDebounceMs));
      const current = JSON.parse(dataJson.current);
      if (!isValidForSubmit(form, current)) {
        setBlocked(true);
        return;
      }

      const result = await submitForm(form.key, form.version, current);
      if (result.kind === 'saved') {
        setServerErrors([]);
        setSaved(result.submission);
      } else {
        setServerErrors(result.errors);
      }
    } catch (error) {
      setFailure(String(error));
    } finally {
      setSubmitting(false);
    }
  };

  const failedRuns = saved?.behaviourRuns.filter((run) => run.status === 'Failed') ?? [];

  return (
    <Container maxWidth="sm" sx={{ py: 4 }}>
      <Paper sx={{ p: 3 }}>
        {!form ? (
          failure ? <Alert severity="error">{failure}</Alert> : <CircularProgress aria-label="Loading form" />
        ) : (
          <Stack spacing={2}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 2 }}>
              <Typography variant="h5" component="h1">{form.title ?? form.key}</Typography>
              <TextField
                select
                size="small"
                label="Version"
                sx={{ minWidth: 100 }}
                value={form.version}
                onChange={(event) => changeVersion(Number(event.target.value))}
              >
                {versions
                  .filter((version) => version.status === 'Published')
                  .map((version) => (
                    <MenuItem key={version.version} value={version.version}>
                      v{version.version}
                    </MenuItem>
                  ))}
              </TextField>
            </Box>

            <JsonForms
              schema={form.schema}
              uischema={form.uischema}
              data={data}
              renderers={renderers}
              cells={materialCells}
              validationMode={showErrors ? 'ValidateAndShow' : 'ValidateAndHide'}
              additionalErrors={additionalErrors}
              onChange={({ data: next }) => handleFormChange(next)}
            />

            {(blocked || serverErrors.length > 0) && (
              <Alert severity="error">The form wasn't saved. Fix the highlighted fields and submit again.</Alert>
            )}
            {failure && <Alert severity="error">{failure}</Alert>}
            {saved && (
              <Alert severity={failedRuns.length > 0 ? 'warning' : 'success'}>
                Saved against v{saved.version}
                {typeof saved.outputs.reference === 'string' && <> with reference <strong>{saved.outputs.reference}</strong></>}.
                {failedRuns.map((run) => (
                  <div key={run.behaviour}>{run.behaviour} failed: {run.error}</div>
                ))}
              </Alert>
            )}

            <Stack direction="row" spacing={1}>
              <Button variant="contained" onClick={submit} disabled={submitting}>
                {submitting ? 'Submitting…' : 'Submit'}
              </Button>
              <Button onClick={reset} disabled={submitting}>Clear</Button>
            </Stack>
          </Stack>
        )}
      </Paper>
    </Container>
  );
}
