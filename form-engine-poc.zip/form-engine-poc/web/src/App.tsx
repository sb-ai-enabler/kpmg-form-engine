import FormPage from './FormPage';

const formKey = new URLSearchParams(window.location.search).get('form') ?? 'expense-claim';

export default function App() {
  return <FormPage key={formKey} formKey={formKey} />;
}
