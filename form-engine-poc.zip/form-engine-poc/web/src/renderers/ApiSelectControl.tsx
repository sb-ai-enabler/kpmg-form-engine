import { useEffect, useMemo, useState } from 'react';
import { Resolve, rankWith, toDataPath, type ControlProps, type Tester } from '@jsonforms/core';
import { useJsonForms, withJsonFormsControlProps } from '@jsonforms/react';
import { CircularProgress, InputAdornment, MenuItem, TextField } from '@mui/material';
import { getLookup, type LookupOption } from '../api';

/** Takes priority over the default renderers for any control with options.lookup. */
export const apiSelectTester = rankWith(
  10,
  ((uischema) => uischema.type === 'Control' && Boolean(uischema.options?.lookup)) as Tester,
);

function ApiSelectControl({ data, path, id, label, required, enabled, visible, errors, uischema, handleChange }: ControlProps) {
  const formData = useJsonForms().core?.data;
  const lookup: string = uischema.options?.lookup;
  const lookupParams: Record<string, string> = uischema.options?.lookupParams ?? {};

  const paramValues = Object.entries(lookupParams).map(([name, scope]) => [
    name,
    Resolve.data(formData, toDataPath(scope)),
  ]);
  const paramsKey = JSON.stringify(paramValues);

  const [options, setOptions] = useState<LookupOption[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string>();
  const [loadedKey, setLoadedKey] = useState<string>();

  useEffect(() => {
    const entries: [string, unknown][] = JSON.parse(paramsKey);
    // A lookup can't be filtered until all of its parent fields have values.
    if (entries.some(([, value]) => value === undefined || value === null || value === '')) {
      setOptions([]);
      setLoadError(undefined);
      setLoading(false);
      setLoadedKey(paramsKey);
      return;
    }

    const controller = new AbortController();
    setLoading(true);
    setLoadError(undefined);
    getLookup(lookup, Object.fromEntries(entries.map(([name, value]) => [name, String(value)])), controller.signal)
      .then((loaded) => {
        setOptions(loaded);
        setLoadedKey(paramsKey);
        setLoading(false);
      })
      .catch((error: unknown) => {
        if (controller.signal.aborted) return;
        setOptions([]);
        setLoadError(error instanceof Error ? error.message : 'Options could not be loaded');
        setLoading(false);
      });
    return () => controller.abort();
  }, [lookup, paramsKey]);

  // Clear a selection that isn't available any more, for example after its parent field changed.
  useEffect(() => {
    if (loadedKey === paramsKey && data !== undefined && !options.some((option) => option.value === data)) {
      handleChange(path, undefined);
    }
  }, [loadedKey, paramsKey, options, data, path, handleChange]);

  const selectableValue = useMemo(
    () => (options.some((option) => option.value === data) ? data : ''),
    [options, data],
  );

  if (!visible) return null;

  const message = loadError ? `Options could not be loaded: ${loadError}` : errors;

  return (
    <TextField
      select
      fullWidth
      id={id}
      variant="outlined"
      label={label}
      required={required}
      disabled={!enabled || loading}
      value={selectableValue}
      error={Boolean(message)}
      helperText={message || ' '}
      onChange={(event) => handleChange(path, event.target.value || undefined)}
      slotProps={{
        input: {
          endAdornment: loading ? (
            <InputAdornment position="end" sx={{ mr: 3 }}>
              <CircularProgress size={16} aria-label="Loading options" />
            </InputAdornment>
          ) : undefined,
        },
      }}
    >
      {options.map((option) => (
        <MenuItem key={option.value} value={option.value}>
          {option.label}
        </MenuItem>
      ))}
    </TextField>
  );
}

export default withJsonFormsControlProps(ApiSelectControl);
