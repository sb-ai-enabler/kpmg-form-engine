# Form Engine POC

Turns a JSON template into a working form, from the browser to its own SQL table. A developer writes the template and runs one script. The script generates the C# code and database migration, and the React app renders the form from the template.

## Run it

Requires the .NET 10 SDK, the `dotnet-ef` tool and Node 24.

```
dotnet run --project api/FormEngine.Api
```

In a second terminal:

```
cd web
npm install
npm run dev
```

Open http://localhost:5173, or http://localhost:5173/?form=<key> for a form other than `expense-claim`. The API listens on http://localhost:5264 and creates `formengine.db` on first start.

Run the tests with `dotnet test`.

## Add or change a form

1. Add or edit a template in `api/FormEngine.Api/FormTemplates/<key>/v<number>.json`.
2. Stop the API, then run:
   ```
   ./scripts/generate-form.ps1 <key>
   ```
3. Review the generated changes and restart the API, which applies any migration.

Use `-Migration <name>` to name the migration. If you don't, the script names it for you, and it doesn't add one if the table hasn't changed.

The API refuses to start if a published template doesn't match its generated code, and the error tells you which script to run. To check this in CI, run `dotnet run --project tools/FormEngine.Generator -- check`.

### What gets generated

For `expense-claim`, in `api/FormEngine.Api/Features/ExpenseClaim/`:

| File | Purpose |
|---|---|
| `ExpenseClaimSubmission.g.cs` | Domain entity, mapped to the `ExpenseClaimSubmissions` table |
| `ExpenseClaimDto.g.cs` | The form's data, and its mapping to and from the entity |
| `SubmitExpenseClaimCommand.g.cs`, `SubmitExpenseClaimHandler.g.cs` | Command and handler that save a submission |
| `GetExpenseClaimQuery.g.cs`, `GetExpenseClaimHandler.g.cs` | Query and handler that read a submission |
| `IExpenseClaimRepository.g.cs`, `ExpenseClaimRepository.g.cs` | Repository interface and EF Core implementation |
| `ExpenseClaimController.g.cs` | `POST /api/forms/expense-claim/versions/{version}/submissions` and `GET /api/forms/expense-claim/submissions/{id}` |
| `ExpenseClaimRegistration.g.cs` | DI registration, called from `Features/FormFeatures.g.cs` |

Each run overwrites `.g.cs` files, so don't edit them. Every generated class is `partial`, so custom code goes in a separate file, such as `ExpenseClaimSubmission.Custom.cs`, which the script leaves alone. To add logic to the submission flow, use a behaviour.

Handlers call the shared `SubmissionProcessor` for validation and behaviours. Changes to `Forms/` apply to every form without regenerating. CQRS uses the small interfaces in `Forms/Cqrs.cs`, not MediatR.

## Template format

See [expense-claim/v1.json](api/FormEngine.Api/FormTemplates/expense-claim/v1.json).

| Key | Purpose |
|---|---|
| `status` | `draft`, `published` or `retired` |
| `title` | Heading shown on the form |
| `schema` | [JSON Schema](https://json-schema.org/) for the data and its validation, and the source of the table's columns |
| `uischema` | [JsonForms](https://jsonforms.io/) layout and SHOW/HIDE/ENABLE/DISABLE rules |
| `options.lookup` on a control | Fills the field as a dropdown from `/api/lookups/{name}` |
| `options.lookupParams` on a control | Passes other fields' values to the lookup, for cascading dropdowns |
| `behaviours` | The C# behaviours to run, each with a `trigger`, `args` and optional `when` condition |

The API checks these rules on startup for every published or retired version:

- Rule and `when` conditions must have `scope`, `schema` and `failWhenUndefined: true`. AND/OR conditions aren't supported.
- A field that can be hidden can't be in the root `required` list. Use `if`/`then` to require it conditionally.

Avoid rules that depend on a field that can itself be hidden. The server evaluates rules once against the submitted data, so such a rule would see that field's stale value.

## Fields and columns

| JSON Schema | C# |
|---|---|
| `string` | `string` (`maxLength` sets the column length) |
| `string` with `format: date` | `DateOnly` |
| `string` with `format: date-time` | `DateTimeOffset` |
| `number` | `decimal` |
| `integer` | `long` |
| `boolean` | `bool` |

Nested objects and arrays aren't supported, and the generator fails on them.

Each form has one table covering all its versions, with a `TemplateVersion` column. Draft versions don't affect the table. A column is `NOT NULL` only if the field is in the root `required` list of every version, and values for hidden fields are stored as `NULL`.

| Change in a new version | Result |
|---|---|
| Add a field | New nullable column |
| Remove a field | Column stays, and new rows leave it `NULL` |
| Change a field's type | Generator fails. Use a new field name or template key |

## Versions

To change a form, add a new version file rather than editing a published one, because each stored row records the version it was made against. To stop accepting submissions on a version, set its `status` to `retired`. Nothing prevents editing a published file, so rely on code review for this.

## Add a behaviour

1. Create a class that implements `IBehaviour`, with a unique `Key` and an `ArgsSchema`. Read everything specific to a template from `ctx.Args`.
2. Register it in `Program.cs`: `builder.Services.AddSingleton<IBehaviour, MyBehaviour>();`.
3. Refer to its key from any template's `behaviours` list.

| Trigger | Runs | If it returns field errors | If it throws |
|---|---|---|---|
| `beforeSave` | After validation, before saving | Save is blocked and the API returns 422 | Nothing is saved and the API returns 500 |
| `afterSave` | After saving | Ignored | Submission stays saved and the failure is recorded in its run log |

## POC limits

- There is no authentication, so run this locally only.
- SQLite stores `decimal` as text, so `SUM` and numeric sorting in SQL don't work properly on those columns. SQL Server doesn't have this problem.
- The React page opens a form by its `?form=` key. There's no menu of forms.
