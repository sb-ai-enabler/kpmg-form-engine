﻿using FormEngine.Templates;

// Usage:
//   generate [key]   Writes the generated code for one form, or for all forms
//   check            Fails if the generated code doesn't match the templates

var root = FindRepoRoot();
var templates = Path.Combine(root, CodeGenerator.ApiTemplatesPath);
var features = Path.Combine(root, CodeGenerator.ApiFeaturesPath);

try
{
    return args switch
    {
        ["generate"] => Generate(null),
        ["generate", var key] => Generate(key),
        ["check"] => Check(),
        _ => Usage(),
    };
}
catch (Exception ex) when (ex is FormModelException or InvalidDataException)
{
    Console.Error.WriteLine($"error: {ex.Message}");
    return 1;
}

int Generate(string? key)
{
    if (key is not null)
        FormModel.Build(key, TemplateLoader.LoadForm(templates, key));

    var expected = CodeGenerator.GenerateAll(templates);
    var existing = ExistingFiles();

    foreach (var (path, content) in expected)
    {
        var fullPath = Path.Combine(features, path);
        if (existing.TryGetValue(path, out var current) && Normalize(current) == Normalize(content)) continue;

        Directory.CreateDirectory(Path.GetDirectoryName(fullPath)!);
        File.WriteAllText(fullPath, content);
        Console.WriteLine($"  wrote   {path}");
    }

    foreach (var path in existing.Keys.Where(path => !expected.ContainsKey(path)))
    {
        File.Delete(Path.Combine(features, path));
        Console.WriteLine($"  removed {path}");
    }

    Console.WriteLine("Generated code is up to date.");
    return 0;
}

int Check()
{
    var expected = CodeGenerator.GenerateAll(templates);
    var existing = ExistingFiles();

    var stale = expected
        .Where(file => !existing.TryGetValue(file.Key, out var current) || Normalize(current) != Normalize(file.Value))
        .Select(file => file.Key)
        .Concat(existing.Keys.Where(path => !expected.ContainsKey(path)))
        .ToList();

    foreach (var path in stale)
        Console.Error.WriteLine($"  out of date: {path}");
    Console.WriteLine(stale.Count == 0 ? "Generated code is up to date." : "Run scripts/generate-form.ps1 to update the generated code.");
    return stale.Count == 0 ? 0 : 1;
}

int Usage()
{
    Console.Error.WriteLine("Usage: generate [key] | check");
    return 2;
}

Dictionary<string, string> ExistingFiles() =>
    !Directory.Exists(features)
        ? []
        : Directory.GetFiles(features, "*.g.cs", SearchOption.AllDirectories)
            .ToDictionary(path => Path.GetRelativePath(features, path).Replace('\\', '/'), File.ReadAllText);

static string Normalize(string text) => text.ReplaceLineEndings("\n");

static string FindRepoRoot()
{
    for (var directory = new DirectoryInfo(Directory.GetCurrentDirectory()); directory is not null; directory = directory.Parent)
    {
        if (File.Exists(Path.Combine(directory.FullName, "FormEngine.slnx")))
            return directory.FullName;
    }
    throw new InvalidDataException("Run this from inside the form-engine-poc repository.");
}
