<#
.SYNOPSIS
    Generates all the code for a form from its templates, and adds a migration if the table changed.
.EXAMPLE
    ./scripts/generate-form.ps1 expense-claim
.EXAMPLE
    ./scripts/generate-form.ps1 expense-claim -Migration AddApproverToExpenseClaim
#>
param(
    [Parameter(Position = 0)]
    [string]$Key,
    [string]$Migration
)

$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)

function Invoke-Step([string]$Message, [scriptblock]$Command) {
    Write-Host $Message
    & $Command
    if ($LASTEXITCODE -ne 0) { throw "$Message failed." }
}

$generatorArgs = @('generate')
if ($Key) { $generatorArgs += $Key }

Invoke-Step 'Generating code...' {
    dotnet run --project tools/FormEngine.Generator -- @generatorArgs
}
Invoke-Step 'Building the API (stop the API first if this fails on a locked file)...' {
    dotnet build api/FormEngine.Api --nologo --verbosity quiet
}

Write-Host 'Checking whether the database needs a migration...'
dotnet ef migrations has-pending-model-changes --project api/FormEngine.Api --no-build *> $null
if ($LASTEXITCODE -eq 0) {
    Write-Host 'The database schema is unchanged, so no migration is needed.'
}
else {
    if (-not $Migration) {
        $prefix = if ($Key) { (Get-Culture).TextInfo.ToTitleCase($Key).Replace('-', '') } else { 'Forms' }
        $Migration = "Update$prefix$(Get-Date -Format 'yyyyMMddHHmmss')"
    }
    Invoke-Step "Adding migration $Migration..." {
        dotnet ef migrations add $Migration --project api/FormEngine.Api --output-dir Data/Migrations --no-build
    }
    Invoke-Step 'Building the API with the new migration...' {
        dotnet build api/FormEngine.Api --nologo --verbosity quiet
    }
}

Write-Host 'Done. Review the changes, then restart the API to apply any migration.'
